function dx = nonlinear_model(~, x, u, m, b, k, g)
    y = x(1);
    ydot = x(2);

    dx = [
        ydot;
        (-m*g + k*(u^2)/(y^2) - b*ydot) / m
    ];
end
